export class Userkind {
    id: any;
    name: any;

}
