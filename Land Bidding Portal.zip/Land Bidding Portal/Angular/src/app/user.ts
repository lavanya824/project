export class User {
    name : any;
    address : string ='';
    mobile : number =0;
    loginId : string = '';
    password : string = '';

    constructor(){

    }
}
