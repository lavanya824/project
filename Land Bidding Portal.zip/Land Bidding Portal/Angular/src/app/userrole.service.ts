import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserroleService {

  user: any;
  role: any;
  constructor() { }
}
