export class Land {
    landId: any;
    surveyNumber: number = 0;
    area: number = 0;
    loginId: any;
    location: string = "";
    price: number = 0;
    constructor() {
        this.landId;
        this.surveyNumber;
        this.area;
        this.landId;
        this.location;
        this.price;
    }
}
