import { Observable } from 'rxjs';

export class Bid {
    bidId: any;
    surveyNumber: number = 0;;
    bidValue: number = 0;
    bidderId: number = 0;
    loginId: any;
    constructor() {
        this.loginId;
        this.bidderId;
        this.surveyNumber;
        this.bidValue;
    }

}
